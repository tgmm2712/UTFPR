#include <stdio.h>

int main(void){

int a, b, prod;

scanf("%d", &a);
scanf("%d", &b);

prod = a * b;

printf("PROD = %d\n", prod);

return 0;

}
