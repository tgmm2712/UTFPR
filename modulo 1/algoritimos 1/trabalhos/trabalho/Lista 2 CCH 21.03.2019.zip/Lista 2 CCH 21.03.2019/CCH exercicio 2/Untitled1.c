#include <stdio.h>

int main(void){

 int a, b, c, d, media;

 scanf("%d", &a);
 scanf("%d", &b);
 scanf("%d", &c);
 scanf("%d", &d);

 media = (a * b - c * d);

 printf("DIFERENCA = %d\n",media);

 return 0;


}
